<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-16833761366"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'AW-16833761366');
    </script>


    <meta charset="UTF-8">
    <title>مندوب الياف بصرية stc 0502974771</title>
    <meta name="description" content="مندوب الياف بصرية STC 0502974771 خدمة تركيب وتأسيس الألياف البصرية مجانا اتصل الأن او راسلنا على تطبيق الواتساب للاشتراك في الالياف البصرية">
    <meta name="keywords" content="ألياف بصرية, خدمات الألياف البصرية STC, تركيب الألياف البصرية السعودية, باقات إنترنت الألياف البصرية, مندوب الألياف البصرية, سرعة الإنترنت الألياف البصرية, تحسين الاتصال بالألياف البصرية, التسجيل في الألياف البصرية STC, دعم الألياف البصرية STC, أسعار الألياف البصرية في السعودية, مقارنة خدمات الألياف البصرية, تغطية الألياف البصرية STC, البنية التحتية للألياف البصرية, تقنيات الألياف البصرية الجديدة, فوائد الألياف البصرية للأعمال">
    <meta name="author" content="STC Baity Fiber">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Open Graph meta tags -->
    <meta property="og:title" content="مندوب الياف بصرية stc 0502974771">
    <meta property="og:description" content="مندوب الياف بصرية STC 0502974771 خدمة تركيب وتأسيس الألياف البصرية مجانا اتصل الأن او راسلنا على تطبيق الواتساب للاشتراك في الالياف البصرية">
    <meta property="og:url" content="https://fiberksa.com">
    <meta property="og:image" content="https://fiberksa.com/uploads/riyadahstc.jpg">
    <meta property="og:type" content="website">
    <meta property="fb:app_id" content="216209513334728" />
    <!-- Twitter Card meta tags -->
    <meta name="twitter:title" content="مندوب الياف بصرية stc 0502974771">
    <meta name="twitter:description" content="مندوب الياف بصرية STC 0502974771 خدمة تركيب وتأسيس الألياف البصرية مجانا اتصل الأن او راسلنا على تطبيق الواتساب للاشتراك في الالياف البصرية ">
    <meta name="twitter:image" content="https://fiberksa.com/uploads/riyadahstc.jpg">
    <meta name="twitter:card" content="https://fiberksa.com/uploads/riyadahstc.jpg">

    <link rel="canonical" href="https://fiberksa.com">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link rel="icon" href="https://fiberksa.com/assets/img/fav.png" sizes="144x144">
    <link rel="icon" href="https://fiberksa.com/assets/img/fav2.png" sizes="96x96">
    <link href="https://fiberksa.com/assets/img/fav.png" rel="apple-touch-icon">


    <link href="https://fiberksa.com/assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="https://fiberksa.com/assets/vendor/bootstrap/css/bootstrap.rtl.min.css" rel="stylesheet">

    <link href="https://fiberksa.com/assets/css/style.css?ver=1.3" rel="stylesheet">
    <link href="https://fiberksa.com/assets/css/desktop.css?ver=1.1" rel="stylesheet">
    <link href="https://fiberksa.com/assets/css/mobile.css?ver=1.1" rel="stylesheet">

</head>

<body>

    <!-- ======= Header ======= -->
    <header class="container topheader " style="background: #fff;">
        <div class="social-links mt-3 hide-on-mobile">
            <a href="#" class="twitter"><i class="fa-brands fa-telegram"></i></a>
            <a href="#" class="facebook"><i class="fa-brands fa-linkedin"></i></a>
            <a href="#" class="instagram"><i class="fa-brands fa-twitter"></i></a>
            <a href="#" class="google-plus"><i class="fa-brands fa-facebook"></i></a>
            <a href="https://wa.me/966502974771/&text=%D9%8A%D8%B3%D8%B9%D8%AF%D9%86%D8%A7%20%D8%A7%D9%84%D8%B1%D8%AF%20%D8%B9%D9%84%D9%89%20%D8%A7%D8%B3%D8%AA%D9%81%D8%B3%D8%A7%D8%B1%D8%A7%D8%AA%D9%83%D9%85%20%D8%B9%D9%84%D9%89%20%D9%85%D8%AF%D8%A7%D8%B1%20%D8%A7%D9%84%D9%8024%20%D8%B3%D8%A7%D8%B9%D8%A9" class="whatsapp">whatsapp</a>
        </div>
        <span class="fa-solid fa-bars mobile-nav-toggle" style="color:var(--primary-color);"></span>
        <a href="https://fiberksa.com/" class="logo me-auto topLogo"><img src="https://fiberksa.com/assets/img/logo.png" alt="" class="img-fluid"></a>

    </header>
    <header id="header">
        <div class="container d-flex align-items-center">

            <span class="menuToggle fa-solid fa-bars hide-on-desktop"></span>

            <nav id="navbar" class="navbar">

                <ul>
                    <li><a class="nav-link scrollto active" href="https://fiberksa.com/index.php#hero">الرئيسية</a></li>
                    <li><a class="nav-link scrollto" href="https://fiberksa.com/index.php#packs">الباقات</a></li>
                    <li><a class="nav-link scrollto" href="https://fiberksa.com/index.php#prices">العروض</a></li>
                    <li><a class="nav-link scrollto" href="https://fiberksa.com/index.php#footer">تواصل معنا</a></li>
                    <li><a class="nav-link scrollto" href="https://fiberksa.com/index.php#blog">مدونة</a></li>


                </ul>

            </nav><!-- .navbar -->
            <a href="https://fiberksa.com/" class="headerLogo logo me-auto" style="margin-left: 0 !important;margin-right: auto;"><img style="max-width: 135px;" src="https://fiberksa.com/assets/img/logo.png" alt="" class="img-fluid"></a>

        </div>
    </header><!-- End Header -->

<main id="main">


    <!-- Hero Section -->
<section id="hero" class="p-0  section" dir="ltr" style="height:80vh;">
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <!-- Slide 1 -->
            <div class="swiper-slide heroSlide" style="    background-position: right 30% top;background-image: url('assets/img/1.jpg');">
                <div class="container" style="padding-top: 40%;">
                    <div class="row gy-4">
                        <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                            <h1 class="heroTitle" style="font-size: 28px;direction: rtl;font-weight: 700;" data-aos="fade-up">أسرع نت بالسعودية؟ أكيد STC</h1>
                            <p class="heroSubtitle text-white" data-aos="fade-up" data-aos-delay="100">مافيه بطء بعد اليوم، شبّك وانطلق بسرعتنا المجنونة</p>
                            <div class="d-flex flex-column flex-md-row heroBtns" style="gap: 15px;" data-aos="fade-up" data-aos-delay="200">
                                <a href="tel:0502974771" class="btn btn-light d-flex gap-2 justify-content-center align-items-center">
                                    <i class="bi bi-telephone-fill"></i>

                                    <span>اتصل بنا الآن</span>
                                </a>
                                <a href="https://wa.me/966502974771" class="btn btn-success d-flex gap-2 justify-content-center align-items-center">
                                    <i class="fa-brands fa-whatsapp"></i>
                                    <span style="direction: rtl;">تواصل مع مندوب STC</span>

                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 order-1 order-lg-2 hero-img">
                            <!-- Optional: Add an image here if needed -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 2 -->
            <div class="swiper-slide heroSlideLeft" style="background-position: left 21% top;background-image: url('assets/img/2.jpg');">
                <div class="container" style="padding-top: 40%;">
                    <div class="row gy-4">
                        <div class="col-lg-6 order-1 order-lg-2 d-flex flex-column justify-content-center">
                            <h1 class="heroTitle" style="font-size: 28px;direction: rtl;font-weight: 700;" data-aos="fade-up">5G من STC... فرق السرعة واضح</h1>
                            <p class="heroSubtitle text-white" data-aos="fade-up" data-aos-delay="100">اتصال ثابت وسرعة تخلّيك دايم بالأول</p>
                            <div class="d-flex flex-column flex-md-row heroBtns" style="gap: 15px;" data-aos="fade-up" data-aos-delay="200">
                                <a href="tel:0502974771" class="btn btn-light d-flex gap-2 justify-content-center align-items-center">
                                    <i class="bi bi-telephone-fill"></i>

                                    <span>اتصل بنا الآن</span>
                                </a>
                                <a href="https://wa.me/966502974771" class="btn btn-success d-flex gap-2 justify-content-center align-items-center">
                                    <i class="fa-brands fa-whatsapp"></i>
                                    <span style="direction: rtl;">تواصل مع مندوب STC</span>

                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 order-2 order-lg-1 hero-img">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 3 -->
            <div class="swiper-slide heroSlide" style="background-image: url('assets/img/3.jpg');background-position: right 5% top 1px;">
                <div class="container" style="padding-top: 40%;">
                    <div class="row gy-4">
                        <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                            <h1 class="heroTitle" style="font-size: 28px;direction: rtl; font-weight: 700;" data-aos="fade-up">فايبر STC... راحة بالك تبدأ من هنا</h1>
                            <p class="heroSubtitle text-white" data-aos="fade-up" data-aos-delay="100">نت سريع وجودة ما تنقص، للبيت اللي يستاهل الأفضل</p>
                            <div class="d-flex flex-column flex-md-row heroBtns" style="gap: 15px;" data-aos="fade-up" data-aos-delay="200">
                                <a href="tel:0502974771" class="btn btn-light d-flex gap-2 justify-content-center align-items-center">
                                    <i class="bi bi-telephone-fill"></i>

                                    <span>اتصل بنا الآن</span>
                                </a>
                                <a href="https://wa.me/966502974771" class="btn btn-success d-flex gap-2 justify-content-center align-items-center">
                                    <i class="fa-brands fa-whatsapp"></i>
                                    <span style="direction: rtl;">تواصل مع مندوب STC</span>

                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 order-1 order-lg-2 hero-img">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 4 -->
            <div class="swiper-slide heroSlideLeft" style="background-image: url('assets/img/4.jpg');background-position: left 2% top 1px;">
                <div class="container" style="padding-top: 40%;">
                    <div class="row gy-4">
                        <div class="col-lg-6 order-1 order-lg-2 d-flex flex-column justify-content-center">
                            <h1 class="heroTitle" style="font-size: 28px;direction: rtl;font-weight: 700;" data-aos="fade-up">عروض 2025؟ لقيناها عند STC</h1>
                            <p class="heroSubtitle text-white" data-aos="fade-up" data-aos-delay="100">أسعار تكسر السوق وخدمة تشرح الصدر</p>
                            <div class="d-flex flex-column flex-md-row heroBtns" style="gap: 15px;" data-aos="fade-up" data-aos-delay="200">
                                <a href="tel:0502974771" class="btn btn-light d-flex gap-2 justify-content-center align-items-center">
                                    <i class="bi bi-telephone-fill"></i>

                                    <span>اتصل بنا الآن</span>
                                </a>
                                <a href="https://wa.me/966502974771" class="btn btn-success d-flex gap-2 justify-content-center align-items-center">
                                    <i class="fa-brands fa-whatsapp"></i>
                                    <span style="direction: rtl;">تواصل مع مندوب STC</span>

                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 order-2 order-lg-1 hero-img">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 5 -->
            <div class="swiper-slide heroSlide" style="    background-position: right 20% top;background-image: url('assets/img/5.jpg');">
                <div class="container" style="padding-top: 40%;">
                    <div class="row gy-4">
                        <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                            <h1 class="heroTitle" style="font-size: 28px;direction: rtl;font-weight: 700;" data-aos="fade-up">ترفيهك علينا... بس شبّك</h1>
                            <p class="heroSubtitle text-white" data-aos="fade-up" data-aos-delay="100">ألعاب، أفلام، بث مباشر؟ كلها تشتغل بدون لاج</p>
                            <div class="d-flex flex-column flex-md-row heroBtns" style="gap: 15px;" data-aos="fade-up" data-aos-delay="200">
                                <a href="tel:0502974771" class="btn btn-light d-flex gap-2 justify-content-center align-items-center">
                                    <i class="bi bi-telephone-fill"></i>

                                    <span>اتصل بنا الآن</span>
                                </a>
                                <a href="https://wa.me/966502974771" class="btn btn-success d-flex gap-2 justify-content-center align-items-center">
                                    <i class="fa-brands fa-whatsapp"></i>
                                    <span style="direction: rtl;">تواصل مع مندوب STC</span>

                                </a>
                            </div>
                        </div>
                        <div class="col-lg-6 order-1 order-lg-2 hero-img">
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="swiper-plugin-pagination"></div>
    </div>
</section>
<!-- /Hero Section -->
    <!-- ======= packs Section ======= -->
<section id="packs">
    <div class="container" data-aos="fade-up" style="max-width: 1500px;">

        <div class="section-title">
            <p class=" fw-bold">باقات انترنت فايبر بيتي من الاتصالات السعودية , استمتع باستخدام الانترنت فى منزلك بسرعة مثالية لتجربة استخدام مميزة</p>
        </div>






        
            <div class="container">
                <div class="row justify-content-center g-4">
                                                                    <div class="col-12 col-md-6 col-lg-4 mb-2">
                            <div class="STCpricing-table STCpopular" style="--primary-color: #8611d7;">
                                                                    <div class="STCpopular-badge">الاكثر مبيعا</div>
                                                                <div class="STCtable-header">
                                    <img src="assets/img/1-AZWHIZB_ar.png" alt="بيتي فايبر انترتينمنت" class="STCicon" />
                                    <h3>بيتي فايبر انترتينمنت</h3>
                                    <div class="STCprice">
                                        460 ريال                                                                            </div>
                                </div>
                                <ul class="STCfeatures">
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                             التحميل تصل الى 500 ميجابت/ث                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            اشتراك stc tv وشاهد vip وشاهد الرياضية                                                                                        </li>
                                                                    </ul>
                                <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                    اشترك الان                                </a>
                            </div>
                        </div>
                                                                    <div class="col-12 col-md-6 col-lg-4 mb-2">
                            <div class="STCpricing-table STCpopular" style="--primary-color: #ff2a53;">
                                                                    <div class="STCpopular-badge">الاكثرمبيعا</div>
                                                                <div class="STCtable-header">
                                    <img src="assets/img/1-AZWHIOC_ar.png" alt="بيتي فايبر ستريم" class="STCicon" />
                                    <h3>بيتي فايبر ستريم</h3>
                                    <div class="STCprice">
                                        402.50 ريال                                                                            </div>
                                </div>
                                <ul class="STCfeatures">
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                             التحميل تصل الى 500 ميجابت/ث                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            اشتراك stc tv كلاسيك وشاهد vip                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            المودم التركيب مجاناً                                                                                        </li>
                                                                    </ul>
                                <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                    اشترك الان                                </a>
                            </div>
                        </div>
                                                                    <div class="col-12 col-md-6 col-lg-4 mb-2">
                            <div class="STCpricing-table " style="--primary-color: #460086;">
                                                                <div class="STCtable-header">
                                    <img src="assets/img/1-AZVV15L_ar.png" alt="بيتي فايبر بيسك" class="STCicon" />
                                    <h3>بيتي فايبر بيسك</h3>
                                    <div class="STCprice">
                                        287.50 ريال                                                                            </div>
                                </div>
                                <ul class="STCfeatures">
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                             التحميل تصل الى 300 ميجابت/ث                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            المودم والتركيب مجاناً                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            اشتراك مجاني في stc tv لايت                                                                                        </li>
                                                                    </ul>
                                <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                    اشترك الان                                </a>
                            </div>
                        </div>
                                                                    <div class="col-12 col-md-6 col-lg-4 mb-2">
                            <div class="STCpricing-table " style="--primary-color: #ff2a53;">
                                                                <div class="STCtable-header">
                                    <img src="assets/img/1-BWM4LOP_ar.png" alt="بيتي فايبر ستريم لايت" class="STCicon" />
                                    <h3>بيتي فايبر ستريم لايت</h3>
                                    <div class="STCprice">
                                        345 ريال                                                                            </div>
                                </div>
                                <ul class="STCfeatures">
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            سرعة التحميل تصل الى 500 ميجابت/ث                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            المودم والتركيب مجاناً                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            اشتراك مجاني في stc tv كلاسيك                                                                                        </li>
                                                                    </ul>
                                <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                    اشترك الان                                </a>
                            </div>
                        </div>
                                                                    <div class="col-12 col-md-6 col-lg-4 mb-2">
                            <div class="STCpricing-table STCpopular" style="--primary-color: #ffd612;">
                                                                    <div class="STCpopular-badge">الأفضل</div>
                                                                <div class="STCtable-header">
                                    <img src="assets/img/PRE_LL_BAITY_300MB_12M_ar.png" alt="بيتي فايبر 500 ميجا&lt;br&gt;مسبق الدفع 12 شهر" class="STCicon" />
                                    <h3>بيتي فايبر 500 ميجا<br>مسبق الدفع 12 شهر</h3>
                                    <div class="STCprice">
                                        4830 ريال                                                                            </div>
                                </div>
                                <ul class="STCfeatures">
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تصل الى 500 ميجابت/ث للتحميل                                                                                         </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تصل الى 125 ميجابت/ث للرفع                                                                                         </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تأسيس وتوصيل وتركيب مجاني                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            جهاز مودم مجاني                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            شهرين اشتراك إضافية مجانية                                                                                        </li>
                                                                    </ul>
                                <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                    اشترك الان                                </a>
                            </div>
                        </div>
                                                                    <div class="col-12 col-md-6 col-lg-4 mb-2">
                            <div class="STCpricing-table " style="--primary-color: #ffd612;">
                                                                <div class="STCtable-header">
                                    <img src="assets/img/PRE_LL_BAITY_300MB_12M_ar.png" alt="بيتي فايبر 500 ميجا&lt;br&gt;مسبق الدفع 6 أشهر" class="STCicon" />
                                    <h3>بيتي فايبر 500 ميجا<br>مسبق الدفع 6 أشهر</h3>
                                    <div class="STCprice">
                                        2415 ريال                                                                            </div>
                                </div>
                                <ul class="STCfeatures">
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تصل الى 500 ميجابت/ث للتحميل                                                                                         </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تصل الى 125 ميجابت/ث للرفع                                                                                         </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تأسيس وتوصيل وتركيب مجاني                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            جهاز مودم مجاني                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            شهر اشتراك إضافي مجاني                                                                                        </li>
                                                                    </ul>
                                <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                    اشترك الان                                </a>
                            </div>
                        </div>
                                                                    <div class="col-12 col-md-6 col-lg-4 mb-2">
                            <div class="STCpricing-table " style="--primary-color: #ff480c;">
                                                                <div class="STCtable-header">
                                    <img src="assets/img/PRE_LL_BAITY_100MB_6M_ar.png" alt="بيتي فايبر 300 ميجا&lt;br&gt;مسبق الدفع 12 شهر" class="STCicon" />
                                    <h3>بيتي فايبر 300 ميجا<br>مسبق الدفع 12 شهر</h3>
                                    <div class="STCprice">
                                        3448.85 ريال                                                                            </div>
                                </div>
                                <ul class="STCfeatures">
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تصل الى 300 ميجابت/ث للتحميل                                                                                         </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تصل الى 100 ميجابت/ث للرفع                                                                                         </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تأسيس وتوصيل وتركيب مجاني                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            جهاز مودم مجاني                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            شهرين اشتراك إضافية مجانية                                                                                        </li>
                                                                    </ul>
                                <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                    اشترك الان                                </a>
                            </div>
                        </div>
                                                                    <div class="col-12 col-md-6 col-lg-4 mb-2">
                            <div class="STCpricing-table " style="--primary-color: #ff480c;">
                                                                <div class="STCtable-header">
                                    <img src="assets/img/PRE_LL_BAITY_100MB_6M_ar.png" alt="بيتي فايبر 300 ميجا&lt;br&gt;مسبق الدفع 6 أشهر" class="STCicon" />
                                    <h3>بيتي فايبر 300 ميجا<br>مسبق الدفع 6 أشهر</h3>
                                    <div class="STCprice">
                                        1838.85 ريال                                                                            </div>
                                </div>
                                <ul class="STCfeatures">
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تصل الى 300 ميجابت/ث للتحميل                                                                                         </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تصل الى 100 ميجابت/ث للرفع                                                                                         </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            تأسيس وتوصيل وتركيب مجاني                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            جهاز مودم مجاني                                                                                        </li>
                                                                            <li>
                                            <i class="fas fa-check"></i>
                                                                                            شهر اشتراك إضافي مجاني                                                                                        </li>
                                                                    </ul>
                                <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                    اشترك الان                                </a>
                            </div>
                        </div>
                                    </div>
            </div>


        








    </div>
</section><!-- End packs Section -->
        <!-- ======= terms Section ======= -->
    <section id="terms" class="skills section-bg">
        <div class="container" data-aos="fade-up">

            <div class="row justify-content-center align-items-center gap-3">
                <div class="col">
                    <div class="row justify-content-center flex-column align-items-center g-2">
                        <h2 class="col text-center fw-bold">اشتراطات فنيه للتركيب</h2>
                        <p class="col fs-5 text-center">لكى تستمتع بالخدمة . يرجى التأكد من وجود بوكسية ألياف بصرية على واجهة المبنى وتزويد المندوب بصورة ورقم القطعة المعدنية بجوار البوكسية كما هو موضح بالصور</p>
                        <div class="social-links mt-3 hide-on-mobile justify-content-center">
                            <a href="#" class="twitter"><i class="fa-brands fa-telegram"></i></a>
                            <a href="#" class="facebook"><i class="fa-brands fa-linkedin"></i></a>
                            <a href="#" class="instagram"><i class="fa-brands fa-twitter"></i></a>
                            <a href="#" class="google-plus"><i class="fa-brands fa-facebook"></i></a>
                            <a href="#" class="google-plus"><i class="fa-brands fa-whatsapp"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <h2 class="col text-center fw-bold mb-4">امثلة على شكل البوكسية</h2>
                    <div class="row justify-content-center align-items-center g-2">
                        <div class="col" style="display: contents;"><img src="assets/img/box1.webp" alt=""></div>
                        <div class="col" style="display: contents;"><img src="assets/img/box2.webp" alt=""></div>
                    </div>

                </div>

            </div>



        </div>
    </section><!-- End terms Section -->
    <style>
    .STCpricing-table {
        width: 90%;
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        padding: 45px 10px;
        text-align: center;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        place-self: center;
    }

    .STCpricing-table:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.5);
    }

    .STCpopular {
        border: 2px solid var(--primary-color);
        position: relative;
    }

    .STCpopular-badge {
        position: absolute;
        top: -12px;
        left: 20px;
        /* Changed from right to left for RTL */
        background-color: var(--primary-color);
        color: #fff;
        padding: 0.25rem 1rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: bold;
    }

    .STCtable-header i {
        font-size: 3rem;
        color: var(--primary-color);
        margin-bottom: 1rem;
    }

    .STCtable-header h3 {
        font-size: 1.5rem;
        color: #333;
        margin: 0;
    }

    .STCtable-header img {
        width: 50%;
    }

    .STCprice {
        font-size: 2rem;
        font-weight: bold;
        color: var(--primary-color);
        margin: 0.5rem 0;
        font-family: Cairo;
    }

    .STCprice span {
        font-size: 1rem;
        font-weight: normal;
        color: #777;
    }

    .STCfeatures {
        list-style: none;
        padding: 0;
        margin: 1.5rem 0;
        width: fit-content;
        margin-left: auto;
        margin-right: auto;
        min-width: 80%;
    }

    .STCfeatures li {
        margin: 0.75rem 0;
        display: flex;
        align-items: center;
        justify-content: start;
        color: #555;
        flex-direction: row;
        font-family: 'Cairo';
        /* Reverse for RTL */
    }

    .STCfeatures i {
        margin-left: 0.5rem;
        /* Changed from margin-right for RTL */
        margin-right: 0;
        font-size: 1rem;
    }

    .STCfeatures .fa-check {
        color: #4caf50;
    }

    .STCfeatures .fa-times {
        color: #f44336;
    }

    .STCfeatures .disabled {
        text-decoration: line-through;
        opacity: 0.6;
    }

    .STCsubscribe-btn {
        display: inline-block;
        background-color: var(--primary-color);
        color: #fff;
        border: none;
        padding: 0.75rem 1.5rem;
        border-radius: 8px;
        font-size: 1rem;
        text-decoration: none;
        transition: background 0.3s ease;
        width: 80%;
    }

    .STCsubscribe-btn:hover {
        background: #f1f1f1;
        color: var(--primary-color);
        border: 1px solid var(--primary-color);
    }

    @media (max-width: 480px) {
        .STCtable-header i {
            font-size: 2.5rem;
        }

        .STCprice {
            font-size: 1.75rem;
        }

        .STCsubscribe-btn {
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
        }
    }
</style>

<section class="section-bg pb-0" id="prices">
    <div class="container">
        <div class="d-flex flex-column justify-content-center align-items-center">
            <div class="col"><img src="assets/img/baity.png" /></div>
            <div class="col">
                <div class="d-flex justify-content-center align-items-center gap-2">

                    <h3 style="direction: ltr" class="fw-bold">5G عروض بيتي</h3>
                    <img src="assets/img/new.png" style="width: 40px;" />
                </div>
            </div>
            <h6 class=" text-center">هى خدمة انترنت لاسلكية عبر تقنية الجيل الخامس تتيح لك الحصول على سعة بيانات لامحدودة وبأقصى سرعة تدعمها الشبكة</h6>
        </div>
    </div>
    </div>
</section>

<!-- ======= prices Section ======= -->
<section class="packs">
    <div>
        <svg class="divider" style="" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
            <path d="M500,98.9L0,6.1V0h1000v6.1L500,98.9z"></path>
        </svg>
    </div>




    
        <div class="container">
            <div class="row justify-content-center g-4">
                                                        <div class="col-12 col-md-6 col-lg-4 mb-2">
                        <div class="STCpricing-table " style="--primary-color: #ab9ff2;">
                                                        <div class="STCtable-header">
                                <img src="assets/img/1-BAIA2E9_ar.png" alt="بيتي 5G لامحدود eSIM" class="STCicon" />
                                <h3>بيتي 5G لامحدود eSIM</h3>
                                <div class="STCprice">
                                    402.5 ريال                                                                            <span>/شهرياً</span>
                                                                    </div>
                            </div>
                            <ul class="STCfeatures">
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    أقصى سرعة تدعمها الشبكة                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    توصيل وراوتر مجاني                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    تنقل بالراوتر في أي مكان                                                                                </li>
                                                            </ul>
                            <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                اشترك الان                            </a>
                        </div>
                    </div>
                                                        <div class="col-12 col-md-6 col-lg-4 mb-2">
                        <div class="STCpricing-table " style="--primary-color: #ab9ff2;">
                                                        <div class="STCtable-header">
                                <img src="assets/img/1-BAIA2DF_ar.png" alt="بيتي 5G لامحدود" class="STCicon" />
                                <h3>بيتي 5G لامحدود</h3>
                                <div class="STCprice">
                                    402.5 ريال                                                                            <span>/شهرياً</span>
                                                                    </div>
                            </div>
                            <ul class="STCfeatures">
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    أقصى سرعة تدعمها الشبكة                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    توصيل وراوتر مجاني                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    تنقل بالراوتر في أي مكان                                                                                </li>
                                                            </ul>
                            <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                اشترك الان                            </a>
                        </div>
                    </div>
                                                        <div class="col-12 col-md-6 col-lg-4 mb-2">
                        <div class="STCpricing-table " style="--primary-color: #ab9ff2;">
                                                        <div class="STCtable-header">
                                <img src="assets/img/1-DJORQ9U_ar.png" alt="بيتي 5G بيسك eSIM" class="STCicon" />
                                <h3>بيتي 5G بيسك eSIM</h3>
                                <div class="STCprice">
                                    299 ريال                                                                            <span>/شهرياً</span>
                                                                    </div>
                            </div>
                            <ul class="STCfeatures">
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    تصل إلى 200 ميجابت/ث للتحميل                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    توصيل وراوتر مجاني                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    انترنت لا محدود                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    اشتراك مجاني في stc tv                                                                                </li>
                                                            </ul>
                            <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                اشترك الان                            </a>
                        </div>
                    </div>
                                                        <div class="col-12 col-md-6 col-lg-4 mb-2">
                        <div class="STCpricing-table " style="--primary-color: #ab9ff2;">
                                                        <div class="STCtable-header">
                                <img src="assets/img/1-BAIA0EK_ar.png" alt="بيتي 5G بيسك" class="STCicon" />
                                <h3>بيتي 5G بيسك</h3>
                                <div class="STCprice">
                                    299 ريال                                                                            <span>/شهرياً</span>
                                                                    </div>
                            </div>
                            <ul class="STCfeatures">
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    تصل إلى 200 ميجابت/ث للتحميل                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    توصيل وراوتر مجاني                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    انترنت لا محدود                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    اشتراك مجاني في stc tv                                                                                </li>
                                                            </ul>
                            <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                اشترك الان                            </a>
                        </div>
                    </div>
                                                        <div class="col-12 col-md-6 col-lg-4 mb-2">
                        <div class="STCpricing-table " style="--primary-color: #ab9ff2;">
                                                        <div class="STCtable-header">
                                <img src="assets/img/1-ECAALCO_ar.png" alt="بيتي 5G انترتينمنت" class="STCicon" />
                                <h3>بيتي 5G انترتينمنت</h3>
                                <div class="STCprice">
                                    353 ريال                                                                            <span>/شهرياً</span>
                                                                    </div>
                            </div>
                            <ul class="STCfeatures">
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    تصل إلى 200 ميجابت/ث للتحميل                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    توصيل وراوتر مجاني                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    انترنت لا محدود                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    اشتراك مجاني في stc tv                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    اشتراك مجاني في شاهد vip والرياضية                                                                                </li>
                                                            </ul>
                            <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                اشترك الان                            </a>
                        </div>
                    </div>
                                                        <div class="col-12 col-md-6 col-lg-4 mb-2">
                        <div class="STCpricing-table " style="--primary-color: #ab9ff2;">
                                                        <div class="STCtable-header">
                                <img src="assets/img/1-DYB0H3A_ar.png" alt="بيتي 5G مسبق الدفع 3 أشهر" class="STCicon" />
                                <h3>بيتي 5G مسبق الدفع 3 أشهر</h3>
                                <div class="STCprice">
                                    1599 ريال                                                                    </div>
                            </div>
                            <ul class="STCfeatures">
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    تصل الى 100 ميجابت/ث للتحميل                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    توصيل وراوتر مجاني                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    انترنت لا محدود                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    تدعم شبكة 5G و 4G                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    صلاحية البيانات 3 اشهر                                                                                </li>
                                                            </ul>
                            <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                اشترك الان                            </a>
                        </div>
                    </div>
                                                        <div class="col-12 col-md-6 col-lg-4 mb-2">
                        <div class="STCpricing-table " style="--primary-color: #ab9ff2;">
                                                        <div class="STCtable-header">
                                <img src="assets/img/1-DKI2KXF_ar.png" alt="بيتي 5G مسبق الدفع 6 أشهر" class="STCicon" />
                                <h3>بيتي 5G مسبق الدفع 6 أشهر</h3>
                                <div class="STCprice">
                                    1605 ريال                                                                    </div>
                            </div>
                            <ul class="STCfeatures">
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    تصل الى 100 ميجابت/ث للتحميل                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    توصيل وراوتر مجاني                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    انترنت لا محدود                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    صلاحية البيانات 6 أشهر                                                                                </li>
                                                            </ul>
                            <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                اشترك الان                            </a>
                        </div>
                    </div>
                                                        <div class="col-12 col-md-6 col-lg-4 mb-2">
                        <div class="STCpricing-table " style="--primary-color: #ab9ff2;">
                                                        <div class="STCtable-header">
                                <img src="assets/img/1-DKHYY6E_ar.png" alt="بيتي 5G مسبق الدفع 12 شهر" class="STCicon" />
                                <h3>بيتي 5G مسبق الدفع 12 شهر</h3>
                                <div class="STCprice">
                                    2980 ريال                                                                    </div>
                            </div>
                            <ul class="STCfeatures">
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    تصل الى 100 ميجابت/ث للتحميل                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    توصيل وراوتر مجاني                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    انترنت لا محدود                                                                                </li>
                                                                    <li>
                                        <i class="fas fa-check"></i>
                                                                                    صلاحية البيانات 12 شهر                                                                                </li>
                                                            </ul>
                            <a href="https://wa.me/966502974771" class="STCsubscribe-btn">
                                اشترك الان                            </a>
                        </div>
                    </div>
                            </div>
        </div>


    








    <div>
        <svg class="divider" style="transform:translateX(-50%) scaleY(-1);" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
            <path d="M500,98.9L0,6.1V0h1000v6.1L500,98.9z"></path>
        </svg>
    </div>
</section><!-- End prices Section -->
    <!-- ======= terms Section ======= -->
<section id="blog" class="skills section-bg">
    <div class="container" data-aos="fade-up">
        <div class="row gap-2">
                                                            <div class="col-lg col-12 p-3">

                        <article class="gambar">
                            <div class="header">
                                <img src="uploads/riyadahstc.jpg" alt="" class="lol">
                            </div>
                            <div class="container-isi">
                                <a href="1">
                                    <div class="title">
                                        <div class="pertama">مندوب الألياف البصرية STC الرياض</div>
                                    </div>

                                    <div class="isi">
                                        <div class="isi1"><p>الرياض تغطية الألياف البصريةstc 0502974771 ممثلو شركة الدليل السعودي STC تعتبر الشركة الرائدة في مجال الاتصالات على مستوى منطقة الخليج والمملكة العربية السعودية وصاحبة العروض والسرعات الممتازة في الألياف البصرية...</div>
                                    </div>

                            </div>
                            <footer class="komentar">
                                <div class="like"><span>المزيد..</span><i class="fa-solid fa-arrow-left"></i></div>
                            </footer>
                            </a>
                        </article>

                    </div>

                                                                                <div class="col-lg col-12 p-3">

                        <article class="gambar">
                            <div class="header">
                                <img src="uploads/qaseemstc.jpg" alt="" class="lol">
                            </div>
                            <div class="container-isi">
                                <a href="2">
                                    <div class="title">
                                        <div class="pertama">خدمات مندوب الألياف البصرية فى القصيم</div>
                                    </div>

                                    <div class="isi">
                                        <div class="isi1"><p>تغطية الألياف البصرية stc في القصيم 0502974771 شركة الاتصالات السعودية شركة الألياف البصرية القصيم 0502974771 منذ تأسيسها ممثل دليل السعودي تعمل شركة الاتصالات السعودية للألياف البصرية<br>وهي على رأس قائمة أفضل...</div>
                                    </div>

                            </div>
                            <footer class="komentar">
                                <div class="like"><span>المزيد..</span><i class="fa-solid fa-arrow-left"></i></div>
                            </footer>
                            </a>
                        </article>

                    </div>

                                                                                <div class="col-lg col-12 p-3">

                        <article class="gambar">
                            <div class="header">
                                <img src="uploads/7ael.jpg" alt="" class="lol">
                            </div>
                            <div class="container-isi">
                                <a href="3">
                                    <div class="title">
                                        <div class="pertama">عروض ألياف بصرية فى حائل</div>
                                    </div>

                                    <div class="isi">
                                        <div class="isi1"><p>إن عروض الألياف البصرية التي تقدمها STC لعملائها بحائل كثيرة جدا ، فلك أن تختار ما يناسب استخداماتك اليومية والشهرية ، فهناك عروض تناسب الأشخاص العاديين والعروض الخاصة بالبزنس وعروض...</div>
                                    </div>

                            </div>
                            <footer class="komentar">
                                <div class="like"><span>المزيد..</span><i class="fa-solid fa-arrow-left"></i></div>
                            </footer>
                            </a>
                        </article>

                    </div>

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        </div>


        <div class="d-flex gap-3 mt-2 flex-column flex-lg-row" style="    flex-flow: wrap;">
                                                                                        
                    <a href="4" class="chip">
                        <i class="chip-svg fa-solid fa-tags"></i>
                        <h2 class="chip-content">أسعار الألياف البصرية STC 2024</h2>

                    </a>


                            
                    <a href="5" class="chip">
                        <i class="chip-svg fa-solid fa-tags"></i>
                        <h2 class="chip-content">مندوب تأسيس وتركيب الياف بصرية STC الرياض 0502974771</h2>

                    </a>


                            
                    <a href="6" class="chip">
                        <i class="chip-svg fa-solid fa-tags"></i>
                        <h2 class="chip-content">مندوب ألياف STC الصحافة 0502974771</h2>

                    </a>


                            
                    <a href="7" class="chip">
                        <i class="chip-svg fa-solid fa-tags"></i>
                        <h2 class="chip-content">مندوب ألياف STC الياسمين 0502974771</h2>

                    </a>


                            
                    <a href="8" class="chip">
                        <i class="chip-svg fa-solid fa-tags"></i>
                        <h2 class="chip-content">مندوب ألياف STC الملقا 0502974771</h2>

                    </a>


                            
                    <a href="9" class="chip">
                        <i class="chip-svg fa-solid fa-tags"></i>
                        <h2 class="chip-content">مندوب ألياف STC النرجس 0502974771</h2>

                    </a>


                            
                    <a href="10" class="chip">
                        <i class="chip-svg fa-solid fa-tags"></i>
                        <h2 class="chip-content">مندوب ألياف STC القيروان 0502974771</h2>

                    </a>


                    </div>


    </div>



</section><!-- End terms Section -->
    

</main>


<!-- ======= Footer ======= -->
<footer id="footer">



    <div class="container footer-bottom clearfix">
        <div class="copyright">
            &copy; Copyright <strong><span>STC</span></strong>. All Rights Reserved
        </div>
        <div class="credits">

            Designed by <a href="https://benchmark.com.eg/">BENCHMARK</a>
        </div>



    </div>
</footer><!-- End Footer -->

<div id="preloader"></div>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="fa-solid fa-arrow-up"></i></a>



<a href="https://wa.me/966502974771/&text=%D9%8A%D8%B3%D8%B9%D8%AF%D9%86%D8%A7%20%D8%A7%D9%84%D8%B1%D8%AF%20%D8%B9%D9%84%D9%89%20%D8%A7%D8%B3%D8%AA%D9%81%D8%B3%D8%A7%D8%B1%D8%A7%D8%AA%D9%83%D9%85%20%D8%B9%D9%84%D9%89%20%D9%85%D8%AF%D8%A7%D8%B1%20%D8%A7%D9%84%D9%8024%20%D8%B3%D8%A7%D8%B9%D8%A9" class="callBottom"><i class="fa-brands fa-whatsapp"></i><span>تواصل معنا</span></a>
<!-- Vendor JS Files -->
<script src="https://fiberksa.com/assets/vendor/aos/aos.js"></script>
<script src="https://fiberksa.com/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/tiny-swiper/index.min.js"></script>
<script src="assets/vendor/tiny-swiper/pagination.min.js"></script>
<script src="assets/vendor/tiny-swiper/autoPlay.min.js"></script>
<script src="assets/vendor/tiny-swiper/lazyload.min.js"></script>

<!-- Template Main JS File -->
<script src="https://fiberksa.com/assets/js/main.js?ver=1.1"></script>

</body>

</html>

<script>
    var swiper = new Swiper(".swiper-container", {
        autoplay: {
            delay: 5000,
        },
        loop: true,
        lazyload: {
            loadPrevNext: false,
            loadPrevNextAmount: 1,
            loadOnTransitionStart: false,
            elementClass: "swiper-lazy",
            loadingClass: "swiper-lazy-loading",
            loadedClass: "swiper-lazy-loaded",
            preloaderClass: "swiper-lazy-preloader",
        },
        plugins: [SwiperPluginAutoPlay, SwiperPluginLazyload],
    });
</script>